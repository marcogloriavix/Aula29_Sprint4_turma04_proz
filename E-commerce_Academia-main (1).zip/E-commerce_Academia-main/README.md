# E-commerce_Academia

## Objetivo:
Desenvolver um e-commerce para comercialização de roupas esportivas, com foco para quem frequenta academia, para os gêneros masculino e feminino, suplementos desenvolvimento de uma sessão para acompanhar o que o(a) instrutor(a) te recomendou para treinar, exibindo também os dados para contatos do(a) mesmo(a). 

## Especificações do produto:
- O site terá versões em português, espanhol e inglês, considerando que poderá ser acessado somente a nível nacional no Brasil, tanto por brasileiros como por estrangeiros.
- Será possível que o cliente avalie a qualidade do produto adquirido, com o intuito de averiguarmos e a qualidade das marcas que estamos comercializando estão atendendo às expectativas dos nossos clientes. Não será possível avaliar o instrutor;
- A forma de pagamento será somente na moeda corrente do Brasil.
